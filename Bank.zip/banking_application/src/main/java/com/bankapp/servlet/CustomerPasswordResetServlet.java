package com.bankapp.servlet;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bankapp.dao.CustomerDAO;
import com.bankapp.model.Customer;
import com.bankapp.service.EmailNotificationService;
import com.bankapp.service.NotificationService;
import com.bankapp.util.PasswordUtil;

@WebServlet(name = "CustomerPasswordResetServlet", urlPatterns = {"/customer/resetPassword"})
public class CustomerPasswordResetServlet extends HttpServlet {
    private CustomerDAO customerDAO;
    private NotificationService notificationService;

    @Override
    public void init() throws ServletException {
        super.init();
        customerDAO = new CustomerDAO();
        notificationService = new EmailNotificationService();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/customer/resetPassword.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String accountNo = request.getParameter("accountNo");
        String newPassword = request.getParameter("newPassword");

        if (accountNo == null || accountNo.trim().isEmpty() || newPassword == null || newPassword.trim().isEmpty()) {
            request.setAttribute("error", "Account number and new password are required.");
            request.getRequestDispatcher("/customer/resetPassword.jsp").forward(request, response);
            return;
        }

        try {
            Customer customer = customerDAO.getCustomerByAccountNo(accountNo);
            if (customer != null) {
                String hashedPassword = PasswordUtil.hashPassword(newPassword);
                customer.setPassword(hashedPassword);
                customer.setPasswordChanged(true);
                boolean updateSuccess = customerDAO.updateCustomer(customer);

                if (updateSuccess) {
                    // Send email notification
                    sendPasswordChangeNotification(customer.getEmail(), accountNo, newPassword);
                    request.setAttribute("message", "Password reset successful! A notification has been sent to your registered email.");
                } else {
                    request.setAttribute("error", "Failed to update password. Please try again later.");
                }
            } else {
                request.setAttribute("error", "Invalid account number: " + accountNo);
            }
        } catch (NoSuchAlgorithmException e) {
            request.setAttribute("error", "Error hashing password: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            request.setAttribute("error", "An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/customer/resetPassword.jsp").forward(request, response);
    }

    private void sendPasswordChangeNotification(String email, String accountNo, String newPassword) {
        try {
            notificationService.sendPasswordChangeNotification(email, accountNo, newPassword);
        } catch (Exception e) {
            // Log the error, but don't stop the password change process
            System.err.println("Failed to send password change notification: " + e.getMessage());
        }
    }
}