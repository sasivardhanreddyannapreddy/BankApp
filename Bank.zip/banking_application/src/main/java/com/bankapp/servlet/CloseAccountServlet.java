package com.bankapp.servlet;

import com.bankapp.service.CustomerService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "CloseAccountServlet", urlPatterns = {"/customer/close-account"})
public class CloseAccountServlet extends HttpServlet {
    private CustomerService customerService;

    @Override
    public void init() throws ServletException {
        super.init();
        customerService = new CustomerService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward to JSP for account closure confirmation
        request.getRequestDispatcher("/customer/close-account.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String accountNo = (String) session.getAttribute("accountNo");
        String password = request.getParameter("password");

        if (accountNo == null || accountNo.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            request.setAttribute("error", "Account number and password are required");
            request.getRequestDispatcher("/customer/close-account.jsp").forward(request, response);
            return;
        }

        try {
            // Verify the password
            if (!customerService.login(accountNo, password)) {
                request.setAttribute("error", "Invalid password");
                request.getRequestDispatcher("/customer/close-account.jsp").forward(request, response);
                return;
            }

            customerService.closeAccount(accountNo);
            session.invalidate(); // Logout the user
            response.sendRedirect(request.getContextPath() + "/customer/login?message=Account closed successfully");
        } catch (SQLException e) {
            String errorMessage = e.getMessage();
            if (errorMessage.startsWith("Account balance must be zero")) {
                request.setAttribute("error", errorMessage);
            } else {
                request.setAttribute("error", "Error closing account: " + errorMessage);
            }
            request.getRequestDispatcher("/customer/close-account.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "An unexpected error occurred: " + e.getMessage());
            request.getRequestDispatcher("/customer/close-account.jsp").forward(request, response);
        }
    }
}