package com.bankapp.service;

import com.bankapp.dao.CustomerDAO;
import com.bankapp.dao.TransactionDAO;
import com.bankapp.model.Customer;
import com.bankapp.model.Transaction;
import com.bankapp.util.PasswordUtil;

import java.math.BigDecimal;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Date;

public class CustomerService {
    private CustomerDAO customerDAO = new CustomerDAO();
    private TransactionDAO transactionDAO = new TransactionDAO();

    public void registerCustomer(String fullName, String address, String mobileNo, String email, String accountType, BigDecimal initialBalance, Date dateOfBirth, String idProof) throws SQLException, NoSuchAlgorithmException {
        Customer customer = new Customer();
        customer.setFullName(fullName);
        customer.setAddress(address);
        customer.setMobileNo(mobileNo);
        customer.setEmail(email);
        customer.setAccountType(accountType);
        customer.setBalance(initialBalance);
        customer.setDateOfBirth(dateOfBirth);
        customer.setIdProof(idProof);
        
        String accountNo = generateAccountNumber();
        String tempPassword = PasswordUtil.generateTemporaryPassword();
        
        customer.setAccountNo(accountNo);
        customer.setPassword(PasswordUtil.hashPassword(tempPassword));
        
        customerDAO.registerCustomer(customer);
        
        // You should securely send the account number and temporary password to the customer
        System.out.println("Account created: " + accountNo + ", Temporary password: " + tempPassword);
    }

    public boolean login(String accountNo, String password) throws SQLException, NoSuchAlgorithmException {
        Customer customer = customerDAO.getCustomerByAccountNo(accountNo);
        if (customer != null && customer.isAccountActive()) {
            return PasswordUtil.verifyPassword(password, customer.getPassword());
        }
        return false;
    }

    public void changePassword(String accountNo, String newPassword) throws SQLException, NoSuchAlgorithmException {
        Customer customer = customerDAO.getCustomerByAccountNo(accountNo);
        if (customer != null) {
            customer.setPassword(PasswordUtil.hashPassword(newPassword));
            customer.setPasswordChanged(true);
            customerDAO.updateCustomer(customer);
        }
    }

    public BigDecimal getBalance(String accountNo) throws SQLException {
        Customer customer = customerDAO.getCustomerByAccountNo(accountNo);
        return customer != null ? customer.getBalance() : BigDecimal.ZERO;
    }

    public void deposit(String accountNo, BigDecimal amount) throws SQLException {
        Customer customer = customerDAO.getCustomerByAccountNo(accountNo);
        if (customer != null) {
            BigDecimal updatedBalance = customer.getBalance().add(amount);
            customer.setBalance(updatedBalance);
            customerDAO.updateCustomer(customer);

            // Get customer ID
            int customerId = customerDAO.getCustomerIdByAccountNo(accountNo);
            
            // Add transaction record
            Transaction transaction = new Transaction();
            transaction.setCustomerId(customerId);
            transaction.setTransactionType("Deposit");
            transaction.setAmount(amount);
            transaction.setBalance(updatedBalance); // Set the updated balance in transaction record
            transactionDAO.addTransaction(transaction);
        }
    }

    public boolean withdraw(String accountNo, BigDecimal amount) throws SQLException {
        Customer customer = customerDAO.getCustomerByAccountNo(accountNo);
        if (customer != null && customer.getBalance().compareTo(amount) >= 0) {
            BigDecimal updatedBalance = customer.getBalance().subtract(amount);
            customer.setBalance(updatedBalance);
            customerDAO.updateCustomer(customer);

            // Get customer ID
            int customerId = customerDAO.getCustomerIdByAccountNo(accountNo);
            
            // Add transaction record
            Transaction transaction = new Transaction();
            transaction.setCustomerId(customerId);
            transaction.setTransactionType("Withdrawal");
            transaction.setAmount(amount);
            transaction.setBalance(updatedBalance); // Set the updated balance in transaction record
            transactionDAO.addTransaction(transaction);
            return true;
        }
        return false;
    }

    public void closeAccount(String accountNo) throws SQLException {
        Customer customer = customerDAO.getCustomerByAccountNo(accountNo);
        if (customer != null && customer.getBalance().compareTo(BigDecimal.ZERO) == 0) {
            customerDAO.deleteCustomerByAccountNo(accountNo);
        } else {
            throw new SQLException("Account balance must be zero to close the account");
        }
    }
    private String generateAccountNumber() {
        // Implement account number generation logic
        return "ACC" + System.currentTimeMillis();
    }

    public int getCustomerIdByAccountNo(String accountNo) throws SQLException {
        return customerDAO.getCustomerIdByAccountNo(accountNo);
    }
}
