package com.bankapp.servlet;

import com.bankapp.service.CustomerService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

@WebServlet("/customer/close-account")
public class CloseAccountServlet extends HttpServlet {
    private CustomerService customerService = new CustomerService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        closeAccount(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        closeAccount(request, response);
    }

    private void closeAccount(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("accountNo") != null) {
            String accountNo = (String) session.getAttribute("accountNo");
            try {
                BigDecimal balance = customerService.getBalance(accountNo);
                if (balance.compareTo(BigDecimal.ZERO) == 0) {
                    customerService.closeAccount(accountNo);
                    session.invalidate();
                    response.sendRedirect(request.getContextPath() + "/customer/login.jsp?accountClosed=true");
                } else {
                    request.setAttribute("errorMessage", "Account balance must be zero to close the account");
                    request.getRequestDispatcher("/customer/dashboard.jsp").forward(request, response);
                }
            } catch (SQLException e) {
                throw new ServletException("Account closure failed", e);
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/customer/login.jsp");
        }
    }
}
